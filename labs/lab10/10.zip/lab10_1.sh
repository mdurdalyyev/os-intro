#!/bin/bash
mkdir ~/backup
cp lab10_1.sh  ~/backup/backup.sh
gzip ~/backup/backup.sh